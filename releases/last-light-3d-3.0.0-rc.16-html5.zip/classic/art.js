import {drawBackrooms} from './backrooms-art.js';
import {phaseActive} from './phase.js';
import {WORK_OBJECTS} from './story.js';
import {sectorDecor,sectorActors,cinemaOverlay} from './sector-art.js';
import {sceneryBackdrop,sceneryCanopy} from './sector-scenery.js';
import {drawApparition,drawJanitor,drawPhaseRipple} from './actor-art.js';
// Native 480×270 pixel artwork. Four-value ramps, one upper-left light.
// No per-pixel noise: wear marks are deterministic connected clusters.
export const RAMPS={teal:['#9db8a1','#628e82','#355c59','#193c40'],brick:['#b4a782','#7c8069','#4e6259','#263f40'],iron:['#adb9a0','#6d9189','#3e6264','#1d3c43'],rust:['#e4bb78','#b17d54','#754f3e','#403b35'],gold:['#ffdfa0','#dcad66','#946e49','#513f37'],blue:['#a6c2bd','#648e98','#3d5b70','#243b4b'],cloth:['#d4d2a0','#9ba97e','#657b62','#354e48'],skin:['#ffe0a2','#dfb57b','#aa7955','#654d3c']};
const blend=(a,b,t)=>{const x=parseInt(a.slice(1),16),y=parseInt(b.slice(1),16);return '#'+[16,8,0].map(s=>Math.round(((x>>s)&255)*(1-t)+((y>>s)&255)*t).toString(16).padStart(2,'0')).join('');};
const BEARINGS = ['→','↘','↓','↙','←','↖','↑','↗'];
export class Art{
 constructor(canvas){this.canvas=canvas;this.c=canvas.getContext('2d',{alpha:false});this.c.imageSmoothingEnabled=false;this.t=0;this.n=0;this.cam=0;}
 rect(x,y,w,h,col){this.c.fillStyle=this.ambientColors?.get(col)??col;this.c.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}
 line(x,y,w,col){this.rect(x,y,w,1,col);}
 box(x,y,w,h,r){this.rect(x,y,w,h,r[3]);this.rect(x,y,w-1,h-1,r[1]);this.line(x,y,w-1,r[0]);this.rect(x,y,1,h-1,r[0]);this.rect(x+w-2,y+1,1,h-2,r[2]);this.line(x+1,y+h-2,w-2,r[2]);}
 label(s,x,y,color='#e9d8a7',size=6){this.c.fillStyle=color;this.c.font=`${size}px monospace`;this.c.fillText(s,Math.round(x),Math.round(y));}
 glow(x,y,rx,ry,color='#efc679',alpha=.15){const c=this.c;c.save();c.globalCompositeOperation='lighter';c.globalAlpha=alpha;c.translate(x,y);c.scale(rx,ry);let g=c.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,color);g.addColorStop(1,'#102c3000');c.fillStyle=g;c.beginPath();c.arc(0,0,1,0,Math.PI*2);c.fill();c.restore();}
 pipe(x,y,w,h,vertical=false,r=RAMPS.iron){this.box(x,y,w,h,r);if(vertical){for(let yy=y+12;yy<y+h;yy+=36){this.rect(x-2,yy,w+4,4,r[3]);this.rect(x-2,yy,w+3,1,r[0]);this.rect(x+1,yy+5,2,6,RAMPS.rust[2]);this.rect(x+2,yy+9,1,5,RAMPS.rust[3]);}}else{for(let xx=x+18;xx<x+w;xx+=43){this.rect(xx,y-2,4,h+4,r[3]);this.rect(xx,y-2,1,h+3,r[0]);this.rect(xx+1,y+h+2,2,5,RAMPS.rust[2]);}}}
 valve(x,y,r=9){const k=r/9;const rr=(dx,dy,w,h,col)=>this.rect(x+dx*k,y+dy*k,Math.max(1,w*k),Math.max(1,h*k),col);const p=RAMPS.rust;
   rr(-5,-9,10,3,p[1]);rr(-8,-6,3,12,p[1]);rr(-5,6,10,3,p[3]);rr(5,-6,3,12,p[3]);rr(-7,-7,3,3,p[0]);rr(5,-7,3,3,p[1]);rr(-7,5,3,3,p[2]);rr(5,5,3,3,p[3]);rr(-4,-8,8,1,p[0]);rr(-7,-4,1,8,p[0]);
   for(let k=0;k<4;k++){const a=k*Math.PI/2+.4;for(let d=1;d<r-2;d++)this.rect(x+Math.cos(a)*d,y+Math.sin(a)*d,2,2,k<2?p[2]:p[1]);}this.box(x-2,y-2,4,4,RAMPS.gold);}
 window(x,y,w,h,id){const c=this.c,n=this.n;this.box(x-3,y-3,w+6,h+6,RAMPS.iron);const day=['#cfcd9d','#aebd9b','#90a89d','#718d8c'],night=['#536c81','#405c70','#304a61','#243d51'];this.rect(x,y,w,h,blend(day[1],night[2],n));for(let j=0;j<4;j++){this.rect(x,y+j*h/4,w,h/4,blend(day[j],night[j],n));}
   // Restrained checker dithering only along broad sky band boundaries.
   for(let k=0;k<2;k++)for(let xx=0;xx<w;xx+=2)this.rect(x+xx+(k%2),y+h/2+k,1,1,blend(day[1],night[1],n));
   this.rect(x+8,y+14,w/2,3,blend('#e2ddbd','#526e7b',n));this.rect(x+13+(this.t*1.2+id*11)%(w-24),y+10,14,2,blend('#e8dfb9','#526d79',n));
   for(let k=0;k<5;k++){let yy=y+h-13-(k*7+id*13)%20;this.rect(x+k*18-4,yy,20,h-(yy-y),blend('#748b81','#243e50',n));this.rect(x+k*18-2,yy-2,16,2,blend('#a0a58b','#3d5365',n));for(let z=0;z<3;z++){this.rect(x+k*18+z*5,yy+5,2,3,blend('#c5bb83','#e8c27b',n));}}
   if(n>0){c.globalAlpha=n;this.rect(x+w-20,y+8,7,7,'#e6dfad');this.rect(x+w-17,y+6,5,7,night[0]);c.globalAlpha=1;}
   this.rect(x+w/2-1,y,3,h,RAMPS.iron[3]);this.line(x,y+h/2,w,RAMPS.iron[2]);this.rect(x-2,y+h,w+4,4,RAMPS.iron[3]);this.line(x-2,y+h,w+4,RAMPS.iron[0]);}
 fan(x,y,r=13){this.box(x-r-3,y-r-3,r*2+6,r*2+6,RAMPS.iron);this.rect(x-r,y-r,r*2,r*2,RAMPS.iron[3]);for(let k=0;k<4;k++){const angle=this.t*(1-this.n*.94)*5+k*Math.PI/2;for(let d=2;d<r-1;d++){const bx=x+Math.cos(angle)*d,by=y+Math.sin(angle)*d;this.rect(bx-1,by-1,4,4,RAMPS.iron[k<2?2:1]);if(d%2===0)this.rect(bx-1,by-1,2,1,RAMPS.iron[0]);}}this.box(x-2,y-2,4,4,RAMPS.rust);this.rect(x-r,y-r,1,r*2,RAMPS.iron[0]);}
 desk(x,y,id){this.box(x,y,56,5,RAMPS.rust);this.rect(x+3,y+5,3,23,RAMPS.iron[2]);this.rect(x+48,y+5,3,23,RAMPS.iron[3]);this.box(x+34,y+6,16,20,RAMPS.teal);this.line(x+37,y+12,10,RAMPS.teal[3]);this.rect(x+39,y+10,4,1,RAMPS.gold[1]);this.box(x+4,y-15,19,13,RAMPS.iron);this.rect(x+6,y-13,14,8,blend('#aac49b','#476364',this.n));this.label(id%2?'17:59':'SAVE',x+7,y-7,'#436660',4);this.rect(x+11,y-2,4,2,RAMPS.iron[2]);for(let i=0;i<3;i++){this.rect(x+28+i%2,y-2-i*2,15-i*2,2,i===2?'#d4cda9':'#a9ad92');this.line(x+30,y-3-i*2,8,'#eef0cc');}this.box(x+45,y-8,5,7,RAMPS.gold);}
 lamp(x,y){this.rect(x-1,y-18,2,17,RAMPS.iron[3]);this.box(x-10,y,21,4,RAMPS.iron);this.rect(x-7,y+4,15,2,blend('#e7ddb0','#ffdda2',this.n));if(this.n>.05){this.glow(x,y+6,40,16,'#efd293',.24*this.n);this.glow(x,y+58,55,39,'#efb968',.17*this.n);}}
 wall(floor,cam){const r=RAMPS.brick;this.rect(0,0,480,270,blend('#526e66','#233e45',this.n));const par=cam*.24;for(let row=0;row<7;row++)for(let i=-1;i<18;i++){const v=(i*7+row*11+30)%3,x=i*36-(par%36)+(row%2?18:0),y=row*32;this.rect(x,y,35,31,blend([r[1],'#78816b','#737d68'][v],['#344e4d','#314b4b','#2d484a'][v],this.n));this.line(x,y,35,blend('#919781','#3c5753',this.n));this.rect(x+34,y+1,1,30,blend(r[2],r[3],this.n));if(v===1){this.rect(x+24,y+20,6,2,blend('#637261','#294448',this.n));this.rect(x+26,y+18,4,2,blend('#637261','#294448',this.n));}if(v===2){this.line(x+3,y+4,10,blend('#9a9d80','#47605a',this.n));}}
   if(floor===2){for(let band=0;band<5;band++)this.rect(0,band*31,480,31,blend(['#a7baa3','#b7c4a6','#c6cba5','#cfd0a7','#b8b99b'][band],['#233a51','#293f56','#30495d','#3b5565','#4c676d'][band],this.n));
   for(let i=-1;i<14;i++){const x=i*43-((cam*.12)%43),h=25+(i*17+80)%44;this.rect(x,153-h,37,h,blend('#738d88','#233f51',this.n));this.line(x+2,151-h,29,blend('#9aa494','#3d5965',this.n));for(let j=0;j<3;j++)this.rect(x+7+j*8,160-h,3,5,blend('#b8b38b','#dfbd7b',this.n));}
   this.rect(0,153,480,59,blend('#7b8d7a','#3a5455',this.n));this.line(0,153,480,blend('#b5b79b','#778c80',this.n));
   const moonX=345-cam*.035;this.c.globalAlpha=this.n;this.rect(moonX,22,13,16,'#e0dcb1');this.rect(moonX-2,25,17,10,'#e0dcb1');this.rect(moonX+5,21,9,13,'#30495d');this.c.globalAlpha=1;
   this.rect(30+(this.t*2)%450,52,35,3,blend('#e4dfba','#536b77',this.n));this.rect(37+(this.t*2)%450,49,18,3,blend('#e4dfba','#536b77',this.n));}
   // Far layer: same windows in two shifts, changing skyline and offices.
   for(let i=-1;floor!==2&&i<7;i++){let x=i*116-((cam*.12)%116)+23;this.window(x,31,76,floor===2?92:66,i+5);}
   // Mid layer: pipes, fans, desks. Different dressing on every floor.
   const mid=cam*.56;for(let i=-1;i<7;i++){const x=i*142-(mid%142);if(floor===0){this.pipe(x+12,7,8,203,true);this.pipe(x+20,111,100,6);this.valve(x+16,139);const variant=((i%3)+3)%3;this.box(x+56,variant===1?144:131,66,variant===1?64:77,variant===2?RAMPS.iron:RAMPS.teal);this.box(x+62,variant===1?151:143,53,variant===1?19:29,RAMPS.iron);this.rect(x+66,variant===1?154:147,45,variant===1?11:21,RAMPS.iron[3]);for(let k=0;k<6;k++)this.rect(x+70+k*7,variant===1?155:151,2,variant===1?8:13,RAMPS.rust[2]);this.label(['PRESSURE','HOT WATER','UNIT 03'][variant],x+70,185,'#adc3a1',5);if(variant===0){this.box(x+80,120,16,12,RAMPS.iron);this.valve(x+88,126,4);}if(variant===1){this.pipe(x+72,125,8,19,true);this.rect(x+102,192,7,7,RAMPS.rust[2]);this.rect(x+99,196,4,5,RAMPS.rust[2]);}if(variant===2){this.box(x+68,190,21,10,RAMPS.rust);this.label('03',x+72,197,RAMPS.gold[0],5);}this.rect(x+70,190,20,3,RAMPS.gold[2]);this.box(x+97,180,11,11,RAMPS.iron);this.line(x+99,185,7,RAMPS.gold[1]);this.rect(x+60,variant===1?144:131,60,2,RAMPS.teal[0]);for(let k=0;k<3;k++)this.rect(x+65+k*11,201,7,2,RAMPS.rust[2]);}
     else if(floor===1){this.desk(x+20,200,i);this.pipe(x,12,142,4);if(i===2){this.box(x+98,119,35,90,RAMPS.rust);this.box(x+103,128,25,11,RAMPS.gold);this.label('GARY',x+106,136,RAMPS.gold[3],6);this.rect(x+124,169,3,2,RAMPS.gold[0]);this.label('BACK MON.',x+103,153,'#c1b78d',4);}}
     else{this.box(x+20,156,75,54,RAMPS.iron);if(i%2===0)this.fan(x+56,180,19);else{for(let v=0;v<6;v++){this.box(x+26,161+v*7,62,4,RAMPS.iron);}this.pipe(x+38,136,8,20,true);}this.pipe(x+98,130,12,80,true);this.pipe(x+92,127,25,6);this.box(x+16,207,83,5,RAMPS.rust);}}
   for(let i=0;i<5;i++){let x=i*143-((cam*.38)%143)+60;this.lamp(x,18);const c=this.c;c.strokeStyle=RAMPS.iron[3];c.lineWidth=2;c.beginPath();c.moveTo(x-43,0);c.quadraticCurveTo(x-30+Math.sin(this.t*.8+i)*3,38,x-15,4);c.stroke();}
   this.rect(0,212,480,30,blend('#3e5c54','#203c40',this.n));this.line(0,213,480,blend('#87947b','#435b54',this.n));
 }
 platform(p){const {x,y,w,phase,surface}=p,xx=x-this.cam;const isActive=phaseActive(p,this.gameplayNight);if(xx>500||xx+w< -20||!isActive||y<(this.viewTop??-1e6)-25||y>(this.viewBottom??1e6))return;const r=phase==='night'?RAMPS.blue:phase==='day'?RAMPS.gold:RAMPS.iron;
   if(phase){this.glow(xx+w/2,y+3,w*.65,13,phase==='night'?'#78a9c4':'#e8bd72',.08);this.box(xx,y,w,7,r);for(let k=0;k<w-6;k+=12){this.rect(xx+3+k,y+3,6,2,r[2]);this.rect(xx+3+k,y,3,1,r[0]);}}
   else{this.box(xx,y,w,18,surface==='carpet'?RAMPS.teal:RAMPS.iron);this.rect(xx+1,y+3,w-2,4,blend('#798b77','#4c685e',this.n));for(let k=0;k<w;k+=24){const variant=Math.floor((x+k)/24)%3;this.line(xx+k+3,y+2,variant===0?14:variant===1?8:18,'#b4b79a');this.rect(xx+k+19,y+8,3,3,RAMPS.iron[3]);this.rect(xx+k+19,y+8,2,1,RAMPS.rust[0]);this.rect(xx+k+20,y+11,2,4,RAMPS.rust[2]);if(surface==='grate'){for(let j=0;j<3;j++)this.rect(xx+k+3+j*5,y+7,2,7,RAMPS.iron[3]);}else if(variant===1){this.rect(xx+k+5,y+12,9,2,RAMPS.iron[3]);this.rect(xx+k+8,y+10,6,3,RAMPS.iron[3]);}}}}
 servicePlaque(x,y,width,title,controls){
   x-=this.cam;
   if(x+width<0||x>480||y+25<this.viewTop||y>this.viewBottom)return;
   this.box(x,y,width,controls?25:14,RAMPS.iron);
   this.rect(x+2,y+2,width-5,controls?20:9,'#233a3a');
   this.line(x+4,y+3,width-9,'#869c87');
   this.label(title,x+5,y+11,'#edd4a1',6);
   if(controls)this.label(controls,x+5,y+20,'#b3c8bd',6);
 }
 serviceRoute(s){
   const route=s.sectorData.relay;
   if(!route)return;
   const takeoff=route.steps[0],landing=route.steps.at(-1),zh=s.lang==='zh';
   this.servicePlaque(takeoff.x-28,takeoff.y-58,76,zh?'↑ 检修捷径':'↑ UPPER ROUTE',zh?'空格跳  X 切换':'SPACE / X');
   this.servicePlaque(landing.x+51,landing.y-54,43,zh?'捷径灯':'RELAY');
 }
 item(item,index){if(item.got||item.present===false||item.y<(this.viewTop??-1e6)-30||item.y>(this.viewBottom??1e6))return;const x=item.x-this.cam,y=item.y+Math.sin(this.t*2+index)*2;this.glow(x,y,15,15,'#f3c982',.16);if(item.kind==='valve'){this.valve(x,y,6);}else if(item.kind==='lunch'){this.box(x-6,y-4,13,10,RAMPS.gold);this.box(x-2,y-7,5,3,RAMPS.iron);this.rect(x-5,y-1,11,2,RAMPS.rust[2]);}else if(item.kind==='water'){this.box(x-5,y-4,10,10,RAMPS.blue);this.rect(x+5,y-4,6,2,RAMPS.blue[0]);this.rect(x+9,y-6,3,3,RAMPS.blue[1]);this.rect(x-2,y-7,5,2,RAMPS.blue[0]);}else{this.box(x-5,y-6,10,13,RAMPS.cloth);this.line(x-3,y-2,6,RAMPS.cloth[2]);this.line(x-3,y+1,5,RAMPS.cloth[2]);}
   this.rect(x-1,y-14,2,2,RAMPS.gold[0]);this.label(''+(index+1),x-1,y-18,'#e5d6a4',5);
 }
 player(p){const c=this.c,x=Math.round(p.x-this.cam),y=Math.round(p.anim==='fallDeath'?Math.min(p.y,(this.viewTop||0)+218):p.y),t=this.t;let frame=0,squash=0,bob=0,legs=[0,0],arm=0,rot=0,alpha=1,scale=1;
   if(p.anim==='ghostDeath'){const k=Math.min(1,(p.deathTime||0)/.55);bob=-6*k;arm=-7*k;legs=[-2*k,2*k];rot=Math.sin(t*15)*.05*k;alpha=1-Math.max(0,((p.deathTime||0)-.55)/.35);}
   else if(p.anim==='death'){const k=Math.min(1,(p.deathTime||0)/.7);rot=k*1.25;legs=[3*k,-2*k];arm=5*k;bob=k*3;}
   else if(p.anim==='fallDeath'){const k=Math.min(1,(p.deathTime||0)/.8);legs=[-4,4];arm=-9;bob=k*18;alpha=1-k;}
   else if(p.anim==='revive'){const k=1-Math.min(1,(p.animTime||0)/.65);alpha=Math.min(1,k*2);bob=(1-k)*9;legs=[-2*(1-k),2*(1-k)];arm=7*(1-k);}
   else if(p.anim==='interact'){squash=3;bob=4;legs=[-2,3];arm=5;}
   else if(p.anim==='hurt'){rot=Math.sin(t*28)*.09;arm=-4;}
   else if(p.anim==='door'){bob=Math.sin(t*12);}
   else if(p.land>0){squash=p.land>.07?2:1;}else if(!p.grounded){frame=p.vy<0?10:11;legs=p.vy<0?[-3,1]:[2,-2];arm=p.vy<0?-4:2;}else if(Math.abs(p.vx)>5){frame=Math.floor(t*11)%6;legs=[[-3,3],[-2,1],[0,0],[3,-3],[1,-2],[0,0]][frame];bob=[0,-1,-2,0,-1,-2][frame];arm=legs[0];}else{frame=Math.floor(t*2)%4;bob=frame===2?-1:0;}
   c.save();c.globalAlpha=alpha;c.translate(x+7,y+28);c.rotate(rot);c.scale(p.dir*scale,scale);c.translate(-7,-28+squash+bob);
   drawJanitor(this,frame,legs,arm,squash,p.grounded,Math.abs(p.vx)>5,p.dir);
   c.restore();
   if(p.anim==='ghostDeath'){this.rect(x+3,y+5,3,8,'#182b35');this.rect(x+10,y+5,3,8,'#182b35');this.rect(x-1,y+8,18,3,'#526b75');}
   if(this.n>.05&&!['death','ghostDeath','fallDeath'].includes(p.anim)){c.save();c.globalCompositeOperation='lighter';c.globalAlpha=.12*this.n;let hx=x+(p.dir===1?19:-3),hy=y+6;const g=c.createLinearGradient(hx,hy,hx+p.dir*70,hy+18);g.addColorStop(0,'#ffe5a4');g.addColorStop(1,'#ffe5a400');c.fillStyle=g;c.beginPath();c.moveTo(hx,hy);c.lineTo(hx+p.dir*82,hy-15);c.lineTo(hx+p.dir*76,hy+35);c.closePath();c.fill();c.restore();}
 }
 officeMezzanine(s){if(s.floor!==1||this.cam>4140||this.cam+480<3480)return;
   const x=3525-this.cam;this.box(x,68,105,35,RAMPS.iron);this.rect(x+4,72,97,26,s.night?'#23323a':'#587975');this.label('FIRE CONTROL',x+12,83,'#d8cda8',6);this.label(s.night?'DO NOT LOCK':'17:59 / SEALED',x+12,95,s.night?'#d9b18d':'#bac7a8',6);
   const glass=3818-this.cam;this.box(glass,154,153,57,RAMPS.iron);this.rect(glass+4,158,145,49,s.night?'#233642':'#526f70');for(let k=0;k<4;k++){this.rect(glass+7+k*37,158,2,49,'#38565c');this.line(glass+11+k*37,161,22,'#80938a');}if(s.night){for(let k=0;k<5;k++)this.rect(glass+31+k*3,170+k*6,2,7,'#91a6a0');this.label('STILL ON DUTY',glass+48,196,'#bdc5a7',5);}else this.label('GARY / EVACUATED',glass+43,196,'#b2c3a8',5);
   const archive=3908-this.cam;for(let k=0;k<3;k++){this.box(archive+5+k*34,72,25,26,RAMPS.teal);this.line(archive+8+k*34,78,19,RAMPS.iron[3]);this.rect(archive+16+k*34,76,5,2,RAMPS.gold[1]);}this.label('ARCHIVE / 2014',archive+11,65,'#c6c2a2',6);this.pipe(archive+5,136,6,75,true);this.pipe(archive+101,136,6,75,true);
 }
 wrap(message,width,size){this.c.font=`${size}px monospace`;const lines=[];let line='';for(const ch of message){if(this.c.measureText(line+ch).width>width){lines.push(line.trim());line='';}line+=ch;}if(line)lines.push(line.trim());return lines;}
 swingDoor(d){
  const x=d.x-this.cam,y=d.y;
  if(x<-70||x>520||y<this.viewTop-70||y>this.viewBottom+30)return;
  const k=d.openness||0,width=Math.max(3,d.w*(1-k*.84)),depth=Math.round(9*Math.sin(k*Math.PI/2));
  const c=this.c,iron=RAMPS.iron,wood=RAMPS.rust;
  this.box(x-3,y-3,d.w+6,d.h+3,iron);
  this.rect(x,y,d.w,d.h,'#15272d');
  if(k>.04){
   this.rect(x+2,y+3,d.w-3,d.h-3,'#253741');
   this.rect(x+d.w-4,y+1,3,d.h-1,'#bdab7c');
   this.line(x+2,y+d.h-2,d.w-3,'#d1b47a');
   this.glow(x+d.w,y+d.h/2,18+k*13,25,'#e4c58b',.13*k);
  }

  c.save();
  c.beginPath();
  c.moveTo(x,y);c.lineTo(x+width,y-depth);c.lineTo(x+width,y+d.h-depth);c.lineTo(x,y+d.h);c.closePath();
  c.clip();
  this.rect(x,y-depth,width,d.h+depth,wood[2]);
  if(width>6){
   this.box(x+2,y+5-depth*.45,width-4,d.h-14,wood);
   this.rect(x+4,y+9-depth*.45,width-8,Math.floor(d.h*.29),iron[3]);
   this.line(x+4,y+9-depth*.45,width-8,iron[1]);
   this.line(x+4,y+d.h-10-depth*.45,width-7,wood[0]);
  }
  this.rect(x+width-4,y+d.h*.55-depth,3,3,RAMPS.gold[2]);
  this.line(x+width-4,y+d.h*.55-depth,2,RAMPS.gold[0]);
  c.strokeStyle=wood[0];c.lineWidth=1;
  c.beginPath();c.moveTo(x,y+.5);c.lineTo(x+width,y-depth+.5);c.stroke();
  c.restore();
  this.rect(x-1,y+7,3,5,iron[2]);this.line(x-1,y+7,3,iron[0]);
  this.rect(x-1,y+d.h-10,3,5,iron[2]);this.line(x-1,y+d.h-10,3,iron[0]);
 }
 hazard(h,active,floor){const x=h.x-this.cam;if(x<-60||x>520||h.y<(this.viewTop??-1e6)-35||h.y>(this.viewBottom??1e6))return;this.c.save();this.c.translate(0,h.y==null?0:h.y+18-228);this.box(x,222,h.w,6,RAMPS.rust);for(let k=3;k<h.w-3;k+=7)this.rect(x+k,223,3,2,RAMPS.gold[1]);if(h.type==='steam'){this.pipe(x+h.w/2-4,207,8,17,true);if(active)for(let k=0;k<4;k++){const rise=(this.t*38+k*11)%48;this.rect(x+7+Math.sin(this.t*3+k)*5,207-rise,12+k*2,4,'#d0d5bd');}}
   else if(h.type==='fan'){this.fan(x+h.w/2,208,13);if(active)this.glow(x+h.w/2,208,35,28,'#d57c63',.12);}
   else if(h.type==='wire'){for(let k=0;k<3;k++){const yy=217+k*3+Math.sin(this.t*18+k)*2;this.line(x+3,yy,h.w-6,active?'#9fc9d1':'#4d625f');}if(active&&Math.floor(this.t*16)%2)this.glow(x+h.w/2,216,30,12,'#8ed8e8',.2);}
   else{this.box(x+3,205,h.w-6,17,RAMPS.iron);for(let k=0;k<4;k++)this.rect(x+6+k*7+(active?Math.floor(this.t*15)%3:0),210,3,8,RAMPS.rust[active?0:2]);}
   this.label(active?'!':h.warningNow?'?':'z',x+h.w/2-2,197,active?'#f3b07c':'#809b91',7);this.c.restore();}
 ghost(g,active){
  if(!active||g.spawned===false)return;
  const x=(g.xNow??g.x)-this.cam,y=g.yNow??g.y;
  if(x<-50||x>530||y<this.viewTop-38||y>this.viewBottom+28)return;
  drawApparition(this,g,x,y);
  if(g.state==='alert'||g.state==='search'){
   this.label(g.state==='alert'?'!':'?',x-2,y-29,'#efb483',9);
   this.glow(x,y-17,20,12,'#e7ad79',.12);
  }
 }
 routeObjective(s){
   const zh=s.lang==='zh',p=s.player;
   if(s.scene||s.mode!=='playing'||s.door.phase!=='closed'||(p.lifeState!=='alive'&&p.lifeState!=='hurt'))return;
   const target=s.station;
   let label=WORK_OBJECTS[target.scene][zh?1:0];
   let dx=target.x-p.x-7,dy=target.y-p.y-14,ready=Math.hypot(dx,dy)<35;
   if(s.station.done){
     const gate=s.doors.find(door=>door.phase==='closed'&&!door.locked);
     dx=(gate?gate.x:s.exitX)-p.x;dy=(gate?gate.y:s.exitY)-p.y;
     label=gate?(zh?'开闸门':'OPEN GATE'):(zh?'出口':'EXIT');
     ready=gate?Math.abs(dx)<40&&Math.abs(dy)<65:p.grounded&&dx<30&&Math.abs(dy)<12;
   }
   const direction=(Math.round(Math.atan2(dy,dx)/(Math.PI/4))+8)%8;
   this.label(`${ready?'[E]':BEARINGS[direction]}  ${label}`,262,260,s.station.done?'#b9d8cc':'#f1d197',8);
 }
 elevator(x,ready,floor,door){
  x-=this.cam;
  if(x<-55||x>520)return;
  const wave=.6+Math.sin(this.t*2)*.15,phase=door?.phase??'closed',p=door?.progress??0;
  const opening=phase==='opening'?Math.min(1,p/.55):phase==='closed'?0:1;
  const closing=phase==='closing'?Math.min(1,p/.5):0,gap=Math.max(0,Math.round(13*(opening-closing)));
  const c=this.c,r=RAMPS;
  this.box(x-5,141,39,87,r.iron);
  this.rect(x,150,29,77,'#1c3039');
  if(gap){
   this.rect(x+1,152,27,73,'#293e42');
   this.rect(x+10,154,9,68,'#576858');
   for(let yy=158;yy<220;yy+=9)this.line(x+5,yy,18,'#3d5151');
   this.line(x+1,224,27,'#c4ab77');
   this.glow(x+14,184,24,48,'#d8b773',.12*gap/13);
  }
  c.save();c.beginPath();c.rect(x+1,151,27,75);c.clip();
  for(const [left,dir] of [[x+2-gap,-1],[x+15+gap,1]]){
   this.box(left,153,12,72,r.teal);
   this.line(left+2,156,8,r.teal[0]);
   this.rect(left+(dir===1?2:9),160,2,60,r.iron[3]);
   for(let k=0;k<3;k++)this.line(left+2,196+k*4,7,r.teal[2]);
  }
  c.restore();
  this.box(x,136,29,9,r.gold);
  this.rect(x+3,138,22,5,r.gold[3]);
  this.label(floor===2?'HOME':'LIFT',x+6,143,ready?r.gold[0]:r.gold[1],5);
  this.box(x+37,177,8,15,r.iron);
  this.rect(x+39,180,3,3,ready?r.gold[0]:r.rust[1]);
  this.line(x+39,185,3,r.iron[3]);
  this.glow(x+14,141,34,17,ready?'#edcb84':'#8aa58d',wave*.18);
  if(ready&&phase==='closed'){this.label('[E]',x+9,130,'#ead9aa',7);this.glow(x+15,220,30,13,'#edcb84',.18);}
 }
 render(s,dt){this.t=s.time;this.n=s.phaseMix;this.gameplayNight=s.night;this.cam=Math.floor(s.camera);this.viewTop=s.cameraY||0;this.viewBottom=this.viewTop+280;const c=this.c;c.imageSmoothingEnabled=false;if(s.backrooms){drawBackrooms(this,s);return;}if(s.expanded)sceneryBackdrop(this,s);else this.wall(s.floor,this.cam);
   c.save();c.beginPath();c.rect(0,0,480,246);c.clip();c.translate(0,-Math.floor(s.cameraY||0));
   if(s.expanded)sectorDecor(this,s);else this.officeMezzanine(s);
   if(s.expanded)this.serviceRoute(s);
   for(const p of s.platforms)this.platform(p);
   for(const w of s.walls||[])if(phaseActive(w,s.night))this.box(w.x-this.cam,w.y,w.w,w.h,RAMPS.iron);
   for(const lamp of s.checkpoints||[]){const x=lamp.x-this.cam;if(x<-30||x>510||lamp.y<this.viewTop-50||lamp.y>this.viewBottom)continue;this.pipe(x+4,lamp.y-8,5,36,true);this.box(x-4,lamp.y-15,18,11,RAMPS.iron);this.rect(x,lamp.y-12,10,5,'#ffe1a0');this.glow(x+5,lamp.y+5,42,53,'#efc879',lamp.id===s.checkpointId?.2:.09);this.label('SAFE',x-3,lamp.y-20,'#dac997',5);}
   for(const e of s.evidence||[])if(!e.got)this.item({...e,kind:'note'},0);
   for(const d of s.doors||[])this.swingDoor(d);
   for(const h of s.hazards){const cycle=(s.time+(h.offset||0))%(h.period||1),phase=h.day?!s.night:s.night;this.hazard({...h,warningNow:phase&&!h.disabled&&h.period&&cycle<h.warning},!h.disabled&&phase&&(!h.period||cycle>h.warning&&cycle<h.warning+1.4),s.floor);}
   for(let i=-1;!s.expanded&&i<6;i++){if(s.floor===1&&this.cam>3300&&this.cam<4140)continue;const wx=i*239-((this.cam*.72)%239);if(s.floor===0){this.box(wx+30,185,44,27,RAMPS.iron);this.label(i%2?'B-13':'PURGE',wx+37,199,'#9fb09a',5);this.pipe(wx+82,151,7,61,true);}else if(s.floor===1){this.box(wx+18,183,64,29,RAMPS.teal);this.rect(wx+24,189,24,4,RAMPS.iron[3]);this.label(i%2?'NO EXIT':'ARCHIVE',wx+27,204,'#aeb89d',5);}else{this.box(wx+20,190,68,22,RAMPS.iron);for(let k=0;k<4;k++)this.rect(wx+27+k*14,181-k%2*3,8,10,RAMPS.cloth);}}
   if(this.n>0&&!s.expanded){c.globalAlpha=this.n*.2;this.rect(0,0,480,246,'#132d43');c.globalAlpha=1;for(let i=0;i<4;i++){const fx=(i*137-(this.cam*.18)%137+500)%500;this.rect(fx,70+i*33,28,2,'#7794a044');}}
   for(let i=0;i<s.items.length;i++)this.item(s.items[i],i);
   for(const g of s.ghosts)this.ghost(g,g.phase===null||g.phase===(s.night?'night':'day'));
   c.save();c.translate(0,(s.exitY??200)-200);this.elevator(s.exitX,s.expanded?s.station.done:s.items.every(i=>i.got),s.floor,s.door);
   if(s.floor===2&&(!s.expanded||s.sector===5)){const x=s.exitX-100-this.cam;this.box(x-6,193,14,35,RAMPS.iron);this.rect(x-2,197,6,6,s.events?.includes('emergency-light')?'#f3d98e':'#716d55');this.label('E · LIGHT',x-16,187,'#d3c59d',5);}c.restore();if(s.expanded)sectorActors(this,s);this.player(s.player);
   if(s.death?.kind==='ghost'){const p=s.player,k=Math.min(1,s.death.time/.15),x=p.x-this.cam;this.rect(x-9,p.y+10-k*3,11,3,'#617b87');this.rect(x+12,p.y+10-k*3,11,3,'#617b87');}
   c.restore();
   for(const p of s.particles)this.rect(p.x-this.cam,p.y-(s.cameraY||0),p.size??2,p.size??2,p.color);
   if(s.expanded)sceneryCanopy(this,s);
   for(let i=-1;!s.expanded&&i<4;i++){const x=i*390-((this.cam*1.13)%390)-12;this.pipe(x,-4,9,68,true,[RAMPS.iron[1],RAMPS.iron[2],RAMPS.iron[3],'#19393f']);this.pipe(x,63,34,7,false,[RAMPS.iron[1],RAMPS.iron[2],RAMPS.iron[3],'#19393f']);}
   this.rect(0,246,480,24,'#142e34');this.line(0,246,480,'#49665f');for(let i=0;i<3;i++){const lit=i<s.player.hp;this.box(10+i*14,252,10,10,lit?RAMPS.rust:RAMPS.iron);this.rect(13+i*14,254,4,5,lit?'#f0c477':'#31494c');if(lit)this.glow(15+i*14,255,10,8,'#eab86e',.12);}this.label(`HP ${s.player.hp}/3`,54,260,s.player.hp===1?'#ef897c':'#d7c79c',6);this.label(s.lang==='zh'?s.shortZh:s.short,92,259,'#b4c6af',6);this.label(`${s.items.filter(i=>i.got).length}/3`,450,259,'#e9c28a',7);
   if(s.expanded)this.routeObjective(s);
   if(s.messageTimer>0&&!s.scene){const lines=this.wrap(s.message,430,7);const h=lines.length*11+12;this.rect(12,28,456,h,'#142b34ee');this.line(12,28,456,'#a8a783');lines.forEach((line,i)=>this.label(line,22,41+i*11,'#e8dfb9',7));}
   if(s.player.lifeState==='alive'&&([ ...s.items.filter(i=>i.present!==false&&!i.got),...(s.evidence||[]).filter(i=>!i.got)].some(i=>Math.hypot(i.x-s.player.x,i.y-s.player.y-14)<38)||(s.doors||[]).some(d=>d.phase==='closed'&&Math.abs(d.x-s.player.x)<43&&Math.abs(d.y-s.player.y)<65)||(s.player.hp<s.player.maxHp&&(s.checkpoints||[]).some(l=>Math.hypot(l.x-s.player.x,l.y-s.player.y)<28))))this.label('[E]',s.player.x-this.cam-1,s.player.y-(s.cameraY||0)-8,'#f2d89e',6);
   const warning=s.ghosts.find(g=>g.spawned!==false&&phaseActive(g,s.night)&&['alert','chase'].includes(g.state)&&Math.abs((g.xNow??g.x)-s.player.x)<220&&Math.abs((g.yNow??g.y)-s.player.y)<100);
   if(warning){const left=(warning.xNow??warning.x)<s.player.x;this.box(393,5,80,17,RAMPS.iron);this.label(left?'! < WATCH':'WATCH > !',399,16,'#e7ad79',7);}
   if(s.expanded){this.label(`${s.sector+1}/6  ${s.lang==='zh'?s.sectorData.spec.zh:s.sectorData.spec.en}`,12,22,'#e0cda4',7);if(s.pursuit?.warning>0)this.label('!  EXIT >  /  PREPARE',310,22,'#f3c181',7);cinemaOverlay(this,s);}
   if(s.shiftFx>0&&!s.reducedEffects)drawPhaseRipple(this,s);
   if(s.shiftRejected>0)this.label('×',s.player.x-this.cam+6,s.player.y-(s.cameraY||0)-7,'#e6a38a',9);
   if(s.redFlash>0&&!s.reducedEffects){c.globalAlpha=s.redFlash*.28;this.rect(0,0,480,246,'#8e2630');c.globalAlpha=1;}
   if(s.flash>0&&!s.reducedEffects){c.globalAlpha=s.flash*.18;this.rect(0,0,480,246,'#e7d7ad');c.globalAlpha=1;}
   if(s.soundFlash>0){this.box(447,6,26,16,RAMPS.iron);this.label(s.muted?'M OFF':'M ON',450,17,'#f0d399',5);}
   if(s.transition>0){c.globalAlpha=s.transition;this.rect(0,0,480,270,'#0b1d24');c.globalAlpha=1;}
 }
}
